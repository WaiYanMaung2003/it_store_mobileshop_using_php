<?php
	$con=mysqli_connect("localhost","root","","it_store");
?>