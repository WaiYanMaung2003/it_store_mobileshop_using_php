<?php
	
	$con = mysqli_connect("localhost","root","","it_store");

	//getting the brands from brands table.
	function getBrands()
	{
		global $con;
		$get_brand = "SELECT * FROM brands";
		$run_brand = mysqli_query($con,$get_brand);
		while($row_brand = mysqli_fetch_array($run_brand))
		{
			$b_id = $row_brand['b_id'];
			$b_title = $row_brand['b_title'];
			
			echo "<li><a href='glasses.php?brand=$b_title'><i class='fa fa-apple' aria-hidden='true'></i></a><br>$b_title</li>";
		}
	}

	//getting the products from product table.
	function getProduct()
	{
	  if(!isset($_GET['brand']))
	  {
		global $con;
		$get_pro = "SELECT * FROM product order by rand()";
		$run_pro = mysqli_query($con,$get_pro);
		while($row_pro = mysqli_fetch_array($run_pro))
		{ 
			$pro_id = $row_pro['p_id'];
			$pro_brand = $row_pro['p_brands'];
			$pro_model = $row_pro['p_model'];
			$pro_price = $row_pro['p_price'];
			$pro_image = $row_pro['p_image'];
			echo " 
			<div class='col-xl-3 col-lg-3 col-md-6 col-sm-6'>
                  <div class='glasses_box'>
                     <figure><img src='admin/product_images/$pro_image' style='width:400px;height:450px'></figure>
                     <h3><span class='blu'>$</span>$pro_price</h3>
                     <p>$pro_model</p>
					 <a class='read_more' href='login.php?buy_pro=$pro_id'>Buy Now</a>
					 <a href='details.php?pro_id=$pro_id' style='font-size:20px;color:red'>details</a>
                  </div>
               </div>
			
			   
			
			";
			
		}
	  }
	}
	
	
	
?>