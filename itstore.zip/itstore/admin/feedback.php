<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!--navbar-->
    <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-dark  ">
        <div class="container  ">
          <a class="navbar-brand text-warning" href="#"> admin pannel</a>
          <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a class="nav-link text-warning" aria-current="page" href="home.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-warning" href="add product.php">Add Products</a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link text-warning" href="products.php">Products</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-warning" href="orders.php" >Order</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-warning" href="feedback.php" >feedback</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-warning" href="logout.php" >Log out</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
      <!--navbar-->
        
      

      <p class="text-sm-start fs-1 mt-5 fw-bold text-warning text-center">All feedback from database..</p>
		  <?php
				error_reporting(1);
	
				include("connection.php");
	
				$view = "SELECT * FROM feedback";
				$result = mysqli_query($con, $view);
				
				echo "<table class='table table-dark table-striped' border='1' cellspacing='0' cellpadding='15px' align='center'>";
				echo "<thead>
        <tr>
						  <th scope='col'>Email</th>
					  	  <th scope='col'>Phone</th>
					  	  <th scope='col'>Message</th>
					  	 
					  </tr>
            </thead>
					 ";
				
				while(list($eadd, $ph, $msg) = mysqli_fetch_array($result))
				{
          echo "<tbody>";
					echo "<tr>";
					echo "<td>". $eadd ."</td>";
					echo "<td>". $ph ."</td>";
					echo "<td>". $msg ."</td>";
					echo "</tr>";
          echo "</tbody>";
				}
				echo "</table>";
		  ?>

<!--footer-->

        <footer class="bg-dark text-white pt-3 fixed-bottom">
            
                     <small>&copy;luca 2024 bootstrap</small>
                  </div>
                </div>
            </div>
        </footer>
       
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>