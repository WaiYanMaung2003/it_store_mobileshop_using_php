<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <?php
	error_reporting(1);
	
	include("connection.php");
	
	if(isset($_POST['insert']))
	{
		
		$p_brands = $_POST['p_brands'];
		$p_model = $_POST['p_model'];
		$p_price = $_POST['p_price'];
		$p_desc = $_POST['p_desc'];
		
		$p_img = $_FILES['p_img']['name'];
		
		
		
		move_uploaded_file($_FILES['p_img']['tmp_name'],"product_images/$p_img");
		
		$insert_p = "INSERT INTO product VALUES('','$p_brands','$p_model','$p_price','$p_img','$p_desc')";
		$query = mysqli_query($con,$insert_p);
		echo "<script>alert('Product has been successfully inserted into the database.')</script>";
		echo "<script>window.open('add product.php','_self')</script>";	
			
		
	}
?>
</head>
<body>
    <!--navbar-->
    <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-dark  ">
        <div class="container  ">
          <a class="navbar-brand text-warning" href="#"> admin pannel</a>
          <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a class="nav-link text-warning" aria-current="page" href="home.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-warning" href="add product.php">Add Products</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-warning" href="products.php">Products</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-warning" href="orders.php" >Order</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-warning" href="feedback.php" >feedback</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-warning" href="logout.php" >Log out</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
      <!--navbar-->
      
      <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2 align="center">Insert Product</h2>
		  <form method="post" action="add product.php" enctype="multipart/form-data">
			<table border="0" cellpadding="10px" align="center" style="font-size:16px; font-weight:bold;">
				
				<tr>
					<td>Product Brands</td>
					<td>
						<select name="p_brands" required>
							<option>Select brands</option>
							<?php
								$get_brand = "SELECT * FROM brands";
								$run_brand = mysqli_query($con,$get_brand);
								while($row_brand = mysqli_fetch_array($run_brand))
								{
									$b_id = $row_brand['b_id'];
									$b_title = $row_brand['b_title'];
									echo "<option value='$b_title'>$b_title</a></li>";
								}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>Product Model</td>
					<td><input type="text" name="p_model" required></td>
				</tr>
				<tr>
					<td>Product Price</td>
					<td><input type="text" name="p_price" required></td>
				</tr>
				<tr>
					<td>Product Image</td>
					<td><input type="file" name="p_img" required></td>
				</tr>
				<tr>
					<td>Product Description</td>
					<td width="500px"><textarea name="p_desc" cols="20"  rows="10"  required></textarea></td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="insert" value="Insert Product"></td>
				</tr>
			</table>
		  </form>
        </div>
        
      </div>
      
      <div class="clr"></div>
    </div>
  </div>
                
				

<!--footer-->

        <footer class="bg-dark text-white pt-3 fixed-bottom">
            
                     <small>&copy;luca 2024 bootstrap</small>
                  </div>
                </div>
            </div>
        </footer>
        
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>