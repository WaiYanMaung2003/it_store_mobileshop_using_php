<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: rgba(0, 0, 0, 0.3);
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .login-container {
      background-color: rgba(0, 0, 0, 0.3);
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      width: 300px;
    }

    .login-container h2 {
      text-align: center;
      color: #333;
    }

    .login-form {
      display: flex;
      flex-direction: column;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      font-size: 14px;
      color: #333;
      margin-bottom: 5px;
      display: block;
    }

    .form-group input {
      width: 100%;
      padding: 8px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      outline: none;
    }

    .form-group button {
      background-color: #4caf50;
      color: #fff;
      padding: 10px;
      font-size: 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      margin-left: 100px;
      width: 100px;
    }

    .form-group button:hover {
      background-color: #45a049;
      
    }
  </style>
  <?php
	error_reporting(1);
	
	include("connection.php");
	
	if(isset($_REQUEST['login']))
	{
		
		$uname = $_REQUEST['uname'];
		$pass = $_REQUEST['pass'];
		$check = mysqli_query($con,"SELECT name,password FROM user WHERE name='$uname'");
		$run = mysqli_fetch_array($check);
		if(($run['name']==$uname) && ($run['password']==$pass))
		{
			
      echo "<script>location.href='home.php'</script>";
		}
		else
		{
			
      $error = "User name or Password do not match!";
		}
	
	}

?>

</head>
<body>

  <div class="login-container">
  
    <h2>Login</h2>
    <form class="login-form" method="post" >
    <?php error_reporting(1); echo "<font color='lightblue'>$error</font>"; ?> 
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" name="uname" required>
      </div>

      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" name="pass" required>
      </div>

      <div class="form-group">
        <button type="submit" name="login" value="Log in">Log in</button>
      </div>
    </form>
  </div>

</body>
</html>
