<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>log in</title>
  
  <style>
    body{
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url(bg.jpg);
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
}
.container{
    background-color:wheat;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 2px 6px 20px rgba(0, 0, 0, 0.2);
    width: 300px;
    max-width: 100%;
    height: 250px;
}
.user{
    width: 100%;
    padding: 10px;
    margin-bottom: 16px;
    box-sizing: border-box;
    border: 1px solid #cccccc;
    border-radius: 4px;
    font-size: 14px;
    outline: none;
    
}
.password{
    width: 100%;
    padding: 10px;
    margin-bottom: 16px;
    box-sizing: border-box;
    border: 1px solid #cccccc;
    border-radius: 4px;
    font-size: 14px;
    outline: none;
    
}
.submit{
    background-color: #007bff;
            color: #ffffff;
            padding: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100px;
}
.forgot{
    display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 16px;
            font-size: 14px;
            font-size: 20px;
            
}
  </style>
<?php
	error_reporting(1);
	include("connection.php");
	
	$id = $_REQUEST['buy_pro'];
	
	if(isset($_REQUEST['login']))
	{
		
		$email = $_REQUEST['email'];
		$pass = $_REQUEST['pass'];
		$query = mysql_query("SELECT email,password FROM sign_up WHERE email='$email'");
		$arr = mysql_fetch_array($query);

		if(($arr['email']==$email) && ($arr['password']==$pass))
		{
			echo "<script>location.href='buy.php?buy_pro=$id'</script>";
		
		}
		else
		{
			$er="UserID or Password do not match.Try again.";
		}
	}
	
?>

</head>
<body>
  <div class="mother">
  <form method="post">
    <div class="container">
    <center>
    <?php
      echo "<font size='4' color='blue'>".$er;
    ?>
      <input type="text" class="user" placeholder="Username" name="email" required>
      <input type="password" class="password" placeholder="Password" name="pass" required>
      <input type="submit" value="log in" name="login" class="submit"><br>
      <div class="forgot"><a href="Register.php">create an account</a>
        
      </div>
      
    </center>
  </div>
  </form>
</div>
</body>
</html>