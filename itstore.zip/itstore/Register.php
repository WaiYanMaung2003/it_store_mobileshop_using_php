<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>sungla</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      <?php
	error_reporting(1);
	
	include("connection.php");
	
	$fname=$_REQUEST['f'];
	$lname=$_REQUEST['l'];
	$eid=$_REQUEST['eid'];
	$pass=$_REQUEST['pwd'];
	$ph=$_REQUEST['phno'];
	$coun=$_REQUEST['coun'];
	$city=$_REQUEST['city'];
	if(isset($_REQUEST['reg']))
	{
		$sql=mysql_query("SELECT * FROM sign_up WHERE email='$eid' ");
		$arr=mysql_fetch_array($sql);
		if($arr['email']!=$eid)
		{
			if(mysql_query("INSERT INTO sign_up VALUES('$fname','$lname','$eid','$pass','$ph','$city','$coun')"))
			{
	      		echo "<script>location.href='Register-success.php?first=$fname & last=$lname & wel=$eid'</script>";
			}
		}
		else 
		{
			$error= "user already exists";
		}
	}
?>
   </head>
   <!-- body -->
   <body class="main-layout position_head">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.php"><img src="images/logo2.png" alt="#" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                              <li class="nav-item ">
                                 <a class="nav-link" href="index.php">Home</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="about.php">About</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="glasses.php"> product</a>
                              </li>
                              
                              <li class="nav-item active">
                                 <a class="nav-link" href="contact.php">Contact Us</a>
                              </li>
                              <li class="nav-item d_none login_btn">
                                 <a class="nav-link" href="Register.php">Register</a>
                              </li>
                              
                              <li class="nav-item d_none sea_icon">
                                 <a class="nav-link" href="#"><i class="fa fa-shopping-bag" aria-hidden="true"></i><i class="fa fa-search" aria-hidden="true"></i></a>
                              </li>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- end header inner -->
      <!-- end header -->
      <!-- contact section -->
      <div id="contact" class="contact">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
               
                  <form method="post" name="f1" onsubmit="return vali()" class="main_form">
                  <?php
                    echo "<h2><font color=red size=4>$error</font></h2>";
                ?>
                     <div class="row">
                        <div class="col-md-12 ">
                  
                           <h3>Create an account</h3>
                        </div>
                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="first_Name" type="type" name="f" onchange="return fname()" > 
                        </div>
                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="last_Name" type="type" name="l" onchange="return lname()"> 
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Phone Number" type="type" name="phno" onchange="return phone()" > 
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Email" type="type" name="eid" onchange="return email() >                          
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Password" type="type" name="pwd" onchange="return pass()" >                          
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="City" type="type" name="city">                          
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Country" type="type" name="coun">                          
                        </div>
                        
                        <div class="col-md-12">
                           <button class="send_btn" name="reg">Send</button>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
         
      </div>
      </div>
      <!-- end contact section -->
      <!--  footer -->
         
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <script>
         // This example adds a marker to indicate the position of Bondi Beach in Sydney,
         // Australia.
         function initMap() {
           var map = new google.maps.Map(document.getElementById('map'), {
             zoom: 11,
             center: {lat: 40.645037, lng: -73.880224},
             });
         
         var image = 'images/maps-and-flags.png';
         var beachMarker = new google.maps.Marker({
             position: {lat: 40.645037, lng: -73.880224},
             map: map,
             icon: image
           });
         }
      </script>
      <!-- google map js -->
      <!-- end google map js --> 
   </body>
</html>